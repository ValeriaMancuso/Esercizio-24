class SonAccount {
    balanceInit: number;
    fixedDeposit: number = 1000;
    fixedWithdraw: number = 250;
    constructor(_balanceInit: number = 0) {
        this.balanceInit = _balanceInit;
    }

    deposit(amount: number) {
        this.balanceInit += amount;
    }

    withdraw (amount: number) {
        console.log('Stai prelevando: ', amount);
        this.balanceInit -= amount;
    }

    depositFix() {
        this.balanceInit += this.fixedDeposit;
    }
    withdrawFix() {
        this.balanceInit -= this.fixedWithdraw;
    }
}
console.log('SON MOVEMENTS');

let valeAccount = new SonAccount(1000);
valeAccount.deposit(500);
console.log(`Stai depositando: ${valeAccount.balanceInit}`);

valeAccount.withdraw(300);
console.log('Il totale è: ', valeAccount.balanceInit);


class MotherAccount extends SonAccount {
    balanceInit: number;
    private interest: number;
    constructor(_balanceInit: number = 0) {
        super(_balanceInit);
        this.interest = 10;
    }
    deposit(amount: number) {
        this.balanceInit += amount - this.addInterest(amount);
        
    }

    withdraw (amount: number) {
        console.log('Stai prelevando: ', amount);
        this.balanceInit -= amount;
    }
    

    addInterest(amount: number): number {
        let interest = 0;
        interest = amount * (this.interest / 100);
        return interest;
    }
    getInterest() {
        return this.interest;
    }
}
console.log('MOM MOVEMENTS');

let momAccount = new MotherAccount(1000);
momAccount.deposit(1000);
console.log(`Stai depositando: ${momAccount.balanceInit}`);

momAccount.withdraw(450);
console.log('Il totale è: ', momAccount.balanceInit);


console.log('Il tasso di interesse è del ', momAccount.addInterest(100), '%');

